Curso: K3573
Número de grupo: 45
Nombre y legajo de todos los integrantes:
    Ferro, Juan Ignacio - 1677743
    Gilberto, Sebastián Anibal - 1699830
    Massaccese, Bruno Ezequiel - 1683640
    Perez Rikap, Nicolas - 1522942
Email del integrante responsable del grupo: sgilberto@frba.utn.edu.ar